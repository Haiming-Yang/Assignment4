import java.sql.*;
import java.util.ArrayList;

public class DataReader {

private String url = "jdbc:mysql://127.0.0.1:3306/my_schema?"  
        + "user=root&password=Yhm12345.&useUnicode=true&characterEncoding=UTF8";;
private String sql = "select * from 2014302580179_professor_info ";
private Connection getConnection(String url) {
    Connection con = null;
	try {
        con = DriverManager.getConnection(url);
      } catch (SQLException e1) {
        e1.printStackTrace();
      }
      try
      {
        Class.forName("com.mysql.jdbc.Driver");
      } catch (ClassNotFoundException e) {
        e.printStackTrace();
      }
      return con;
}
public ArrayList<ProfessorInfo> readDB(){
	ArrayList< ProfessorInfo> allInfo = new ArrayList<>();
	try
    {
    	  ResultSet rs;  
      Statement sttm = getConnection(url).prepareStatement(sql);
      rs = sttm.executeQuery(sql);
      
      //int numOfProfessors = 26;
      
      while(rs.next()){
      String name = rs.getString(1);
      String eduBg = rs.getString(2);
      String reseaechInterests = rs.getString(3);
      String mail = rs.getString(4);
      String tel = rs.getString(5);
      
    	  ProfessorInfo proinfo = new ProfessorInfo(name, eduBg, mail, tel, reseaechInterests);
    	  allInfo.add(proinfo);
    	  //System.out.println(proinfo.getName());
      }
      sttm.close();
      getConnection(url).close();
      
    } catch (SQLException e) {
      e.printStackTrace();
    }
/*
	for (int i = 0; i < allInfo.size(); i++) {
		System.out.println(allInfo.get(i).geteduBg());
	}
    System.out.println(Integer.toString(allInfo.size()));
    */
	return allInfo;
  }
}


