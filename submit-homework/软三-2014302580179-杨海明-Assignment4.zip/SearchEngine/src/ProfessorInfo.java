
public class ProfessorInfo {
//私有变量
private String name;
private String eduBg;
private String mail;
private String tel;
private String researchInterests;
public ProfessorInfo(String nanme, String eduBg,String mail , String tel, String researchInterest	) {
	// TODO Auto-generated constructor stub
	 setName(nanme);
	 seteduBg(eduBg);
	 setMial(mail);
	 setTel(tel);
	 setResearchInterest(researchInterest);
	
	
}
//get所有私有变量 ，返回string或string[]
public String[] getName() {
	
	return name.split(" |,");
}
public String[] geteduBg() {
	return eduBg.split(" |,");
}
public String[] getMail() {
	return mail.split(" |,");
}
public String[] getTel() {
	return tel.split(" |,");
}
public String[] getResearchInterest() {
	return researchInterests.split(" |\\n");
}
public String getNameS() {
	
	return name;
}
public String geteduBgS() {
	return eduBg;
}
public String getMailS() {
	return mail;
}
public String getTelS() {
	return tel;
}
public String getResearchInterestS() {
	return researchInterests;
}

//set所有私有变量
public void setName(String name1) {
	name = name1;
}
public void seteduBg(String bg1) {
	eduBg = bg1;
}
public void setMial(String mail1) {
	mail = mail1;
}
public void setTel(String tel1) {
	tel = tel1;
}
public void setResearchInterest(String intrest1) {
	researchInterests = intrest1;
}

}
