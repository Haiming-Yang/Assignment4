import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JTextPane;

public class MainGUI {

	private JFrame frmSearchenginePoweredBy;
	private JTextField textField_search;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainGUI window = new MainGUI();
					window.frmSearchenginePoweredBy.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSearchenginePoweredBy = new JFrame();
		frmSearchenginePoweredBy.setTitle("SearchEngine Powered by Steve_yyy");
		frmSearchenginePoweredBy.setBounds(100, 100, 511, 399);
		frmSearchenginePoweredBy.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSearchenginePoweredBy.getContentPane().setLayout(null);
		
		JLabel lblSearch = new JLabel("Search:");
		lblSearch.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		lblSearch.setBounds(26, 21, 87, 42);
		frmSearchenginePoweredBy.getContentPane().add(lblSearch);
		
		textField_search = new JTextField();
		textField_search.setBounds(125, 28, 269, 34);
		frmSearchenginePoweredBy.getContentPane().add(textField_search);
		textField_search.setColumns(10);
		
		JLabel lblResult = new JLabel("Result:");
		lblResult.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		lblResult.setBounds(26, 75, 87, 42);
		frmSearchenginePoweredBy.getContentPane().add(lblResult);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(125, 85, 368, 264);
		frmSearchenginePoweredBy.getContentPane().add(scrollPane);
		
		JTextPane textPane = new JTextPane();
		scrollPane.setViewportView(textPane);
		
		JButton btnSearchNow = new JButton("Search Now");
		btnSearchNow.setBackground(Color.LIGHT_GRAY);
		btnSearchNow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String searchWords = textField_search.getText();
				SearchMain sm = new SearchMain();

				double[]TFs = sm.calTF(searchWords);
				int[]orders = sm.sortByTF(TFs);
				String searchResult = sm.output(orders);
				textPane.setText(searchResult);
				//textPane.setCaretPosition(textPane.getText().length());
				
			}
		});
		btnSearchNow.setBounds(406, 26, 87, 40);
		frmSearchenginePoweredBy.getContentPane().add(btnSearchNow);
	}
}
