
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;



public class SearchMain {
	
	//设置搜索关键字
	public String[] setSearchWords(String words){
		String[] initialSearchWords = words.split(" |,");
		String[]finalSearchWords = ignoreStopwords(initialSearchWords);
		return finalSearchWords;
	}
	//设置过滤字表单
	public String[] setStopWords() {
		String[] stopWordsLists = new String[819];
		try {
		      Scanner input = new Scanner(new File("./stopwordslist.txt"));
		      int i = 0;
		      while (input.hasNextLine()) {
		        stopWordsLists[i] = input.nextLine();
		        i++;
		      }
		      input.close();
		    } catch (FileNotFoundException e) {
		      e.printStackTrace();
		    }
		return stopWordsLists;
		
	}
   //过滤stopwords
	public String[] ignoreStopwords(String[] initialSWs) {
		
	for(String s1 : initialSWs ) {
		for (String s2 : setStopWords()) {
			if (s1.equalsIgnoreCase(s2)) {
				s1 = "";
			}
		}
	}
	String[] finalSWs = initialSWs;
    	return finalSWs;
	}
    //计算tf值
	public double[] calTF(String words){
        int count = 0;
		DataReader dr = new DataReader();
		ArrayList<ProfessorInfo> pi = dr.readDB();
		double[] TFs = new double[pi.size()];
		String[] searchWords = setSearchWords(words);
    	    
		for (ProfessorInfo pInfo : pi) {
			String[] name = pInfo.getName();
			String[] eduBg = pInfo.geteduBg();
			String[] mail = pInfo.getMail();
			String[] tel = pInfo.getTel();
			String[] researchInterest = pInfo.getResearchInterest();
			for (String word : searchWords) {
				for (String nameInfo : name) {
					if (word.equalsIgnoreCase(nameInfo)) {
						TFs[count] += 5;
					}
				}
				for (String eduInfo : eduBg) {
					if (word.equalsIgnoreCase(eduInfo)) {
					TFs[count] += 3;
					}
				}
				for (String mailInfo : mail) {
					if (word.equalsIgnoreCase(mailInfo)) {
					TFs[count] += 3;
					}
				}
				for (String telInfo : tel) {
					if (word.equalsIgnoreCase(telInfo)) {
					TFs[count] += 3;
					}
				}
				for (String riInfo : researchInterest) {
					if (word.equalsIgnoreCase(riInfo)) {
						TFs[count] += 3;
					}
				}
				//tf值除以信息总词数
				TFs[count] = TFs[count]/(name.length+eduBg.length+researchInterest.length+mail.length+tel.length);
				
			}
			count++;	
		}
		return TFs;
	}
		
	//根据tf值给数据排序
    public int[] sortByTF(double[] TFs){
    	int[] order = new int[TFs.length];
    	//order赋初值
    	for (int j = 0; j < order.length; j++) {
			order[j] = j;
			
		}
 
    	for (int a = 0; a < order.length; a++) {
    	      for (int b = a; b>0 ;b--) {
    	        if (TFs[b] <= TFs[(b-1)]) {
    	        	break;}
    	        int temp1 = order[b-1];
    	        double temp2 = TFs[b-1];
    	        order[b-1] = order[(b)];
    	        TFs[b-1] = TFs[(b)];
    	        order[(b)] = temp1;
    	        TFs[(b)] = temp2;
    	      }
    	}
    return order;
    	}
    //给output赋值
    public String output(int[] order) {
    	DataReader dr = new DataReader();
    	ArrayList<ProfessorInfo> pi = dr.readDB();
    	String output = "";
    for (int i:order) {
          output = output + pi.get(i).getNameS() + "\n" + 
        		  pi.get(i).geteduBgS() + "\n" + 
        		  pi.get(i).getResearchInterestS() + "\n" + 
        		  pi.get(i).getMailS() + "\n" + 
            pi.get(i).getTelS() + "\n" + "\n";
    }
    return output;
}
}